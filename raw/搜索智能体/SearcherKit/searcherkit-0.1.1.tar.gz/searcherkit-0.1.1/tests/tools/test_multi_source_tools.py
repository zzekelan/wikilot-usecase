from __future__ import annotations

import asyncio
from collections.abc import Callable
from pathlib import Path

import pytest

from searcherkit.common.errors import RecoverableError
from searcherkit.sources import SourceConfig, add_source_cfg
from searcherkit.sources.file import FileSource
from searcherkit.tools import ToolConfig, build_tool
from searcherkit.tools.search import SearchTool
from searcherkit.tools.visit import VisitTool


SearchFactory = Callable[..., SearchTool]
VisitFactory = Callable[..., VisitTool]
SOURCE_ROOT = Path(__file__).resolve().parents[1] / "fixtures" / "files"
DOC_ID = "source_files.md"


def _expected_search_extensions(
    *,
    query: str = "source-backed-tools",
    source: str,
) -> dict[str, object]:
    return {
        "searched_ids": [DOC_ID],
        "documents": [
            {
                "id": DOC_ID,
                "title": DOC_ID,
                "url": None,
                "query": query,
                "source": source,
            }
        ],
    }


def _expected_visit_extensions(*, source: str) -> dict[str, object]:
    return {
        "documents": [
            {
                "id": DOC_ID,
                "title": DOC_ID,
                "url": None,
                "source": source,
            }
        ],
    }


def _source_names(test_name: str) -> tuple[str, str]:
    return (
        f"tools-multi-runtime-{test_name}",
        f"tools-multi-summary-{test_name}",
    )


def _add_sources(test_name: str) -> tuple[str, str]:
    runtime_name, summary_name = _source_names(test_name)
    add_source_cfg(
        runtime_name,
        SourceConfig(
            type="file",
            name=runtime_name,
            root_path=str(SOURCE_ROOT),
        ),
    )
    add_source_cfg(
        summary_name,
        SourceConfig(
            type="file",
            name=summary_name,
            root_path=str(SOURCE_ROOT),
        ),
    )
    return runtime_name, summary_name


def _direct_search_tool(*, test_name: str) -> SearchTool:
    runtime_name, summary_name = _source_names(test_name)
    return SearchTool(
        {
            runtime_name: FileSource(root_path=SOURCE_ROOT),
            summary_name: FileSource(root_path=SOURCE_ROOT),
        },
        name="search",
    )


def _config_search_tool(*, test_name: str) -> SearchTool:
    source_names = list(_add_sources(test_name))
    tool = build_tool(
        ToolConfig(
            type="search",
            name="search",
            source=source_names,
        )
    )
    assert isinstance(tool, SearchTool)
    return tool


def _direct_visit_tool(*, test_name: str) -> VisitTool:
    runtime_name, summary_name = _source_names(test_name)
    return VisitTool(
        {
            runtime_name: FileSource(root_path=SOURCE_ROOT),
            summary_name: FileSource(root_path=SOURCE_ROOT),
        },
        name="visit",
    )


def _config_visit_tool(*, test_name: str) -> VisitTool:
    source_names = list(_add_sources(test_name))
    tool = build_tool(
        ToolConfig(
            type="visit",
            name="visit",
            source=source_names,
        )
    )
    assert isinstance(tool, VisitTool)
    return tool


@pytest.mark.parametrize("tool_factory", [_direct_search_tool, _config_search_tool])
def test_multi_source_search_run(tool_factory: SearchFactory) -> None:
    async def run() -> None:
        test_name = "search-run"
        runtime_name, summary_name = _source_names(test_name)
        tool = tool_factory(test_name=test_name)
        assert "source" in tool.inputSchema["required"]

        runtime_result = await tool.run(
            query="source-backed-tools",
            source=runtime_name,
        )
        summary_result = await tool.run(
            query="source-backed-tools",
            source=summary_name,
        )

        runtime_content, runtime_extensions = runtime_result
        summary_content, summary_extensions = summary_result
        assert DOC_ID in runtime_content
        assert DOC_ID in summary_content
        assert runtime_extensions == _expected_search_extensions(source=runtime_name)
        assert summary_extensions == _expected_search_extensions(source=summary_name)

    asyncio.run(run())


@pytest.mark.parametrize("tool_factory", [_direct_search_tool, _config_search_tool])
def test_multi_source_search_unknown_source(
    tool_factory: SearchFactory,
) -> None:
    async def run() -> None:
        test_name = "search-unknown"
        runtime_name, summary_name = _source_names(test_name)
        tool = tool_factory(test_name=test_name)

        with pytest.raises(RecoverableError) as exc_info:
            await tool.run(query="pluggable execution", source="missing-source")

        message = str(exc_info.value)
        assert "unknown source 'missing-source'" in message
        assert runtime_name in message
        assert summary_name in message

    asyncio.run(run())


@pytest.mark.parametrize("tool_factory", [_direct_visit_tool, _config_visit_tool])
def test_multi_source_visit_run(tool_factory: VisitFactory) -> None:
    async def run() -> None:
        test_name = "visit-run"
        runtime_name, summary_name = _source_names(test_name)
        tool = tool_factory(test_name=test_name)
        assert "source" in tool.inputSchema["required"]

        runtime_result = await tool.run(
            document_id=DOC_ID,
            source=runtime_name,
            goal="confirm runtime",
        )
        summary_result = await tool.run(
            document_id=DOC_ID,
            source=summary_name,
            goal="confirm summary",
        )

        runtime_content, runtime_extensions = runtime_result
        summary_content, summary_extensions = summary_result
        assert f"[{DOC_ID}](None)" in runtime_content
        assert (
            "runtime source-backed execution"
            in runtime_content
        )
        assert f"[{DOC_ID}](None)" in summary_content
        assert "evidence extraction" in summary_content
        assert runtime_extensions == _expected_visit_extensions(source=runtime_name)
        assert summary_extensions == _expected_visit_extensions(source=summary_name)

    asyncio.run(run())


@pytest.mark.parametrize("tool_factory", [_direct_visit_tool, _config_visit_tool])
def test_multi_source_visit_unknown_source(tool_factory: VisitFactory) -> None:
    async def run() -> None:
        test_name = "visit-unknown"
        runtime_name, summary_name = _source_names(test_name)
        tool = tool_factory(test_name=test_name)

        with pytest.raises(RecoverableError) as exc_info:
            await tool.run(document_id=DOC_ID, source="missing-source")

        message = str(exc_info.value)
        assert "unknown source 'missing-source'" in message
        assert runtime_name in message
        assert summary_name in message

    asyncio.run(run())


@pytest.mark.parametrize("tool_factory", [_direct_visit_tool, _config_visit_tool])
def test_multi_source_visit_missing_document(tool_factory: VisitFactory) -> None:
    async def run() -> None:
        test_name = "visit-missing-document"
        runtime_name, _summary_name = _source_names(test_name)
        tool = tool_factory(test_name=test_name)

        with pytest.raises(RecoverableError, match="file document not found"):
            await tool.run(document_id="missing", source=runtime_name)

    asyncio.run(run())
