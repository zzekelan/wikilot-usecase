from __future__ import annotations

import sys

from searcherkit.cli.main import main


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
