"""Pluggable search-agent runtime."""
